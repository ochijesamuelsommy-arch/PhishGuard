import jsPDF from "jspdf";

function DownloadReportButton({
  result,
  virusTotal,
  safeBrowsing,
}) {
  function downloadPDF() {
    const doc = new jsPDF();

    let y = 20;

    doc.setFontSize(20);
    doc.text("PhishGuard Security Report", 20, y);

    y += 15;

    doc.setFontSize(12);

    doc.text(`URL: ${result.url}`, 20, y);
    y += 10;

    doc.text(`Status: ${result.status}`, 20, y);
    y += 10;

    doc.text(
      `Risk Score: ${result.overall_risk_score}/100`,
      20,
      y
    );
    y += 10;

    doc.text(`Confidence: ${result.confidence}`, 20, y);
    y += 15;

    if (result.ai_analysis) {
      doc.setFontSize(14);
      doc.text("AI Security Analysis", 20, y);

      y += 10;

      doc.setFontSize(12);

      doc.text(
        `Summary: ${result.ai_analysis.summary}`,
        20,
        y,
        { maxWidth: 170 }
      );

      y += 25;

      doc.text(
        `Recommendation: ${result.ai_analysis.recommendation}`,
        20,
        y,
        { maxWidth: 170 }
      );

      y += 20;
    }

    if (safeBrowsing) {
      doc.setFontSize(14);
      doc.text("Google Safe Browsing", 20, y);

      y += 10;

      doc.setFontSize(12);

      doc.text(
        `Safe: ${safeBrowsing.safe ? "Yes" : "No"}`,
        20,
        y
      );

      y += 15;
    }

    if (virusTotal) {
      doc.setFontSize(14);
      doc.text("VirusTotal", 20, y);

      y += 10;

      doc.setFontSize(12);

      doc.text(
        `Harmless: ${virusTotal.harmless ?? "-"}`,
        20,
        y
      );

      y += 10;

      doc.text(
        `Malicious: ${virusTotal.malicious ?? "-"}`,
        20,
        y
      );

      y += 10;

      doc.text(
        `Suspicious: ${virusTotal.suspicious ?? "-"}`,
        20,
        y
      );

      y += 10;

      doc.text(
        `Undetected: ${virusTotal.undetected ?? "-"}`,
        20,
        y
      );
    }

    doc.save("PhishGuard_Report.pdf");
  }

  return (
    <div
      style={{
        marginTop: "25px",
        textAlign: "center",
      }}
    >
      <button
        onClick={downloadPDF}
        style={{
          padding: "14px 30px",
          borderRadius: "12px",
          border: "none",
          background: "#2563eb",
          color: "#fff",
          cursor: "pointer",
          fontSize: "16px",
          fontWeight: "bold",
          transition: "0.3s",
        }}
      >
        📄 Download Security Report
      </button>
    </div>
  );
}

export default DownloadReportButton;