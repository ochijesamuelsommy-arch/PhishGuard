import { motion } from "framer-motion";

function ResultCard({ result }) {
  const safe = result.status === "SAFE";

  return (
    <motion.div
      className="result"
      initial={{
        opacity: 0,
        y: 40,
      }}
      animate={{
        opacity: 1,
        y: 0,
      }}
      transition={{
        duration: 0.7,
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: "20px",
        }}
      >
        <div>
          <h2
            style={{
              color: safe ? "#22c55e" : "#ef4444",
              fontSize: "34px",
              marginBottom: "8px",
            }}
          >
            {safe ? "🟢 SAFE" : "🔴 SUSPICIOUS"}
          </h2>

          <p
            style={{
              color: "#94a3b8",
              fontSize: "17px",
            }}
          >
            {result.message}
          </p>
        </div>

        <motion.div
          animate={{
            scale: [1, 1.08, 1],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
          }}
          style={{
            width: "110px",
            height: "110px",
            borderRadius: "50%",
            background: safe
              ? "rgba(34,197,94,.15)"
              : "rgba(239,68,68,.15)",
            border: `5px solid ${
              safe ? "#22c55e" : "#ef4444"
            }`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "34px",
            fontWeight: "bold",
          }}
        >
          {100 - result.overall_risk_score}
        </motion.div>
      </div>

      <div
        style={{
          marginTop: "30px",
          display: "grid",
          gridTemplateColumns:
            "repeat(auto-fit,minmax(220px,1fr))",
          gap: "20px",
        }}
      >
        <div
          style={{
            background: "#1e293b",
            padding: "18px",
            borderRadius: "15px",
          }}
        >
          <h4 style={{ color: "#38bdf8" }}>
            Risk Score
          </h4>

          <p
            style={{
              fontSize: "26px",
              fontWeight: "bold",
            }}
          >
            {result.overall_risk_score}/100
          </p>
        </div>

        <div
          style={{
            background: "#1e293b",
            padding: "18px",
            borderRadius: "15px",
          }}
        >
          <h4 style={{ color: "#38bdf8" }}>
            Confidence
          </h4>

          <p
            style={{
              fontSize: "26px",
              fontWeight: "bold",
            }}
          >
            {result.confidence}
          </p>
        </div>

        <div
          style={{
            background: "#1e293b",
            padding: "18px",
            borderRadius: "15px",
          }}
        >
          <h4 style={{ color: "#38bdf8" }}>
            Local Scan
          </h4>

          <p
            style={{
              fontSize: "26px",
              fontWeight: "bold",
            }}
          >
            {result.local_scan.score}/100
          </p>
        </div>
      </div>

      {result.local_scan.reasons.length > 0 && (
        <>
          <h3
            style={{
              marginTop: "35px",
              color: "#facc15",
            }}
          >
            ⚠️ Indicators Found
          </h3>

          <ul
            style={{
              marginTop: "15px",
              paddingLeft: "25px",
              color: "#cbd5e1",
            }}
          >
            {result.local_scan.reasons.map(
              (reason, index) => (
                <li
                  key={index}
                  style={{
                    marginBottom: "8px",
                  }}
                >
                  {reason}
                </li>
              )
            )}
          </ul>
        </>
      )}
    </motion.div>
  );
}

export default ResultCard;