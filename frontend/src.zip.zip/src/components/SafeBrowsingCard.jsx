function SafeBrowsingCard({ info }) {
  if (!info) {
    return null;
  }

  const dangerous = !info.safe;

  return (
    <div className="result">
      

      <p>
        <strong>Status:</strong>{" "}
        {dangerous ? "🚨 Dangerous Website" : "✅ Safe"}
      </p>

      {dangerous ? (
        <>
          {info.matches?.map((match, index) => (
            <div key={index}>
              <p>
                <strong>Threat Type:</strong> {match.threatType}
              </p>

              <p>
                <strong>Platform:</strong> {match.platformType}
              </p>

              <p>
                <strong>Entry Type:</strong> {match.threatEntryType}
              </p>
            </div>
          ))}
        </>
      ) : (
        <>
          <p>
            <strong>Threats Detected:</strong> 0
          </p>

          <p>
            <strong>Google Reputation:</strong> No known malicious activity
            found.
          </p>
        </>
      )}
    </div>
  );
}

export default SafeBrowsingCard;