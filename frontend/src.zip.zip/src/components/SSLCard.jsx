import { motion } from "framer-motion";

import GlassCard from "./ui/GlassCard";
import SectionHeader from "./ui/SectionHeader";
import StatusBadge from "./ui/StatusBadge";
import MetricCard from "./ui/MetricCard";

function SSLCard({ info }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 35 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
    >
      <GlassCard>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            marginBottom: "25px",
          }}
        >
          <SectionHeader
            icon="🔒"
            title="SSL Certificate"
          />

          <StatusBadge
            status={info.status}
            successText="VALID"
            dangerText="INVALID"
          />
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "repeat(auto-fit,minmax(220px,1fr))",
            gap: "18px",
          }}
        >
          <MetricCard
            icon="👤"
            title="Issued To"
            value={info.issued_to}
          />

          <MetricCard
            icon="🏢"
            title="Issuer"
            value={info.issuer}
          />

          <MetricCard
            icon="📅"
            title="Valid From"
            value={info.valid_from}
          />

          <MetricCard
            icon="⏳"
            title="Expires"
            value={info.valid_to}
          />

          <MetricCard
            icon="🛡️"
            title="Days Remaining"
            value={`${info.days_remaining} Days`}
          />
        </div>
      </GlassCard>
    </motion.div>
  );
}

export default SSLCard;