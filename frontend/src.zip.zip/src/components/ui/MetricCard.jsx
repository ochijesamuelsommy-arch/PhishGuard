function MetricCard({
  title,
  value,
  icon,
}) {
  return (
    <div
      style={{
        background: "#1e293b",
        padding: "18px",
        borderRadius: "16px",
      }}
    >
      <div
        style={{
          fontSize: "28px",
          marginBottom: "10px",
        }}
      >
        {icon}
      </div>

      <div
        style={{
          color: "#38bdf8",
          fontWeight: "600",
        }}
      >
        {title}
      </div>

      <div
        style={{
          marginTop: "10px",
          fontSize: "20px",
          fontWeight: "700",
          color: "#ffffff",
          wordBreak: "break-word",
        }}
      >
        {value}
      </div>
    </div>
  );
}

export default MetricCard;