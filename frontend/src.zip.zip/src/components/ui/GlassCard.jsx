function GlassCard({ children }) {
  return (
    <div
      style={{
        marginTop: "25px",
        background: "rgba(15,23,42,.75)",
        backdropFilter: "blur(18px)",
        border: "1px solid rgba(56,189,248,.15)",
        borderRadius: "22px",
        padding: "28px",
        transition: ".35s",
        boxShadow:
          "0 10px 40px rgba(0,0,0,.35)",
      }}
    >
      {children}
    </div>
  );
}

export default GlassCard;