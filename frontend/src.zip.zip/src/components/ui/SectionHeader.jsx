function SectionHeader({ icon, title }) {
  return (
    <h2
      style={{
        color: "#38bdf8",
        fontSize: "24px",
        marginBottom: "20px",
        display: "flex",
        alignItems: "center",
        gap: "10px",
      }}
    >
      <span>{icon}</span>
      <span>{title}</span>
    </h2>
  );
}

export default SectionHeader;