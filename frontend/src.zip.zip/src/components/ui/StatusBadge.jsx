function StatusBadge({
  status,
  successText = "SAFE",
  dangerText = "DANGER",
}) {
  const safe =
    status === "SAFE" ||
    status === "Valid" ||
    status === true;

  return (
    <span
      style={{
        padding: "10px 18px",
        borderRadius: "999px",
        fontWeight: "700",
        background: safe
          ? "rgba(34,197,94,.15)"
          : "rgba(239,68,68,.15)",
        color: safe
          ? "#22c55e"
          : "#ef4444",
      }}
    >
      {safe ? `🟢 ${successText}` : `🔴 ${dangerText}`}
    </span>
  );
}

export default StatusBadge;