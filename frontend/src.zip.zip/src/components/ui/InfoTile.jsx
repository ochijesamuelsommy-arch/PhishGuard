function InfoTile({
  icon,
  title,
  value,
}) {
  return (
    <div
      style={{
        background: "#1e293b",
        borderRadius: "16px",
        padding: "18px",
      }}
    >
      <div
        style={{
          fontSize: "28px",
          marginBottom: "10px",
        }}
      >
        {icon}
      </div>

      <div
        style={{
          color: "#38bdf8",
          fontWeight: "600",
        }}
      >
        {title}
      </div>

      <div
        style={{
          marginTop: "10px",
          color: "#ffffff",
          wordBreak: "break-word",
        }}
      >
        {value || "Unknown"}
      </div>
    </div>
  );
}

export default InfoTile;