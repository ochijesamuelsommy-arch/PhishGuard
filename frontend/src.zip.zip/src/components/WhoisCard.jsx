import { motion } from "framer-motion";

function WhoisItem({ icon, title, value }) {
  return (
    <div
      style={{
        background: "#1e293b",
        borderRadius: "15px",
        padding: "18px",
      }}
    >
      <div
        style={{
          fontSize: "28px",
          marginBottom: "10px",
        }}
      >
        {icon}
      </div>

      <div
        style={{
          color: "#38bdf8",
          fontWeight: "600",
          marginBottom: "8px",
        }}
      >
        {title}
      </div>

      <div
        style={{
          color: "#f8fafc",
          wordBreak: "break-word",
        }}
      >
        {value || "Unknown"}
      </div>
    </div>
  );
}

function WhoisCard({ info }) {
  return (
    <motion.div
      className="result"
      initial={{ opacity: 0, y: 35 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
    >
      <h2>📅 WHOIS Information</h2>

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(auto-fit,minmax(220px,1fr))",
          gap: "18px",
          marginTop: "20px",
        }}
      >
        <WhoisItem
          icon="🏢"
          title="Registrar"
          value={info.registrar}
        />

        <WhoisItem
          icon="📅"
          title="Created"
          value={info.creation_date}
        />

        <WhoisItem
          icon="⌛"
          title="Domain Age"
          value={
            info.age_days === "Unknown"
              ? "Unknown"
              : `${info.age_days} days`
          }
        />

        <WhoisItem
          icon="📆"
          title="Expires"
          value={info.expiration_date}
        />
      </div>
    </motion.div>
  );
}

export default WhoisCard;