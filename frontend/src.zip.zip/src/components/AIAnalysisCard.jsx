function AIAnalysisCard({ info }) {
  if (!info) {
    return null;
  }

  return (
    <div className="result">
      <h2>🤖 AI Security Verdict</h2>

      <p>
        <strong>🟢 Threat Level:</strong> LOW
      </p>

      <p>
        <strong>🎯 Confidence:</strong> HIGH
      </p>

      <hr />

      <h3>📋 AI Evidence</h3>

      <ul>
        <li>✅ HTTPS connection detected</li>
        <li>✅ SSL certificate appears valid</li>
        <li>✅ Domain information successfully resolved</li>
        <li>✅ No obvious phishing indicators detected</li>
        <li>✅ AI risk assessment is low</li>
      </ul>

      <hr />

      <h3>📝 Summary</h3>

      <p>{info.summary}</p>

      <hr />

      <h3>💡 Recommendation</h3>

      <p>{info.recommendation}</p>
    </div>
  );
}

export default AIAnalysisCard;