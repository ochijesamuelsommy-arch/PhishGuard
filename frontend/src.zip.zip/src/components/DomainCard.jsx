import { motion } from "framer-motion";

import GlassCard from "./ui/GlassCard";
import SectionHeader from "./ui/SectionHeader";
import InfoTile from "./ui/InfoTile";

function DomainCard({ info }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 35 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
    >
      <GlassCard>
        <SectionHeader
          icon="🌍"
          title="Domain Intelligence"
        />

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "repeat(auto-fit,minmax(220px,1fr))",
            gap: "18px",
          }}
        >
          <InfoTile
            icon="🌐"
            title="Domain"
            value={info.domain}
          />

          <InfoTile
            icon="🖥️"
            title="IP Address"
            value={info.ip_address}
          />

          <InfoTile
            icon="🌍"
            title="Country"
            value={info.country}
          />

          <InfoTile
            icon="🏙️"
            title="City"
            value={info.city}
          />

          <InfoTile
            icon="🏢"
            title="Organization"
            value={info.organization}
          />

          <InfoTile
            icon="🛰️"
            title="ASN"
            value={info.asn}
          />

          <InfoTile
            icon="🔒"
            title="Protocol"
            value={info.protocol}
          />

          <InfoTile
            icon="🏷️"
            title="Hostname"
            value={info.hostname}
          />

          <InfoTile
            icon="🚪"
            title="Port"
            value={info.port}
          />

          <InfoTile
            icon="📁"
            title="Path"
            value={info.path}
          />

          <InfoTile
            icon="🛡️"
            title="Secure Connection"
            value={info.https ? "Yes" : "No"}
          />
        </div>
      </GlassCard>
    </motion.div>
  );
}

export default DomainCard;