import { motion } from "framer-motion";
import ShieldLogo from "./ShieldLogo";

function Hero() {
  return (
    <div
      style={{
        textAlign: "center",
        marginBottom: "50px",
        paddingTop: "20px",
      }}
    >
      <ShieldLogo />

      <motion.h1
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{
          duration: 1,
        }}
        style={{
          fontSize: "56px",
          fontWeight: "800",
          marginTop: "15px",
          marginBottom: "10px",
          color: "#ffffff",
          letterSpacing: "3px",
        }}
      >
        PHISHGUARD
      </motion.h1>

      <motion.h2
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{
          delay: 0.4,
          duration: 1,
        }}
        style={{
          color: "#38bdf8",
          fontWeight: "600",
          marginBottom: "20px",
        }}
      >
        AI Security Intelligence Platform
      </motion.h2>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{
          delay: 0.8,
          duration: 1,
        }}
        style={{
          maxWidth: "750px",
          margin: "0 auto",
          color: "#94a3b8",
          fontSize: "18px",
          lineHeight: "1.8",
        }}
      >
        Protect yourself from phishing attacks using AI-powered
        threat intelligence. Scan URLs, inspect SSL certificates,
        analyze domain reputation, verify Google Safe Browsing,
        cross-check VirusTotal results, and receive intelligent
        security recommendations—all in one place.
      </motion.p>

      <motion.div
        initial={{
          opacity: 0,
        }}
        animate={{
          opacity: 1,
        }}
        transition={{
          delay: 1.2,
          duration: 1,
        }}
        style={{
          marginTop: "25px",
          display: "flex",
          justifyContent: "center",
          gap: "15px",
          flexWrap: "wrap",
        }}
      >
        <span
          style={{
            padding: "8px 18px",
            borderRadius: "25px",
            background: "#1e293b",
            color: "#38bdf8",
            fontWeight: "600",
          }}
        >
          🛡️ AI Detection
        </span>

        <span
          style={{
            padding: "8px 18px",
            borderRadius: "25px",
            background: "#1e293b",
            color: "#38bdf8",
            fontWeight: "600",
          }}
        >
          🌐 VirusTotal
        </span>

        <span
          style={{
            padding: "8px 18px",
            borderRadius: "25px",
            background: "#1e293b",
            color: "#38bdf8",
            fontWeight: "600",
          }}
        >
          🔒 SSL Analysis
        </span>

        <span
          style={{
            padding: "8px 18px",
            borderRadius: "25px",
            background: "#1e293b",
            color: "#38bdf8",
            fontWeight: "600",
          }}
        >
          🤖 Google Safe Browsing
        </span>
      </motion.div>
    </div>
  );
}

export default Hero;