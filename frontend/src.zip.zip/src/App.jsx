import { useState } from "react";
import "./App.css";

import Header from "./components/layout/Header";
import Hero from "./components/layout/Hero";
import SearchBar from "./components/layout/SearchBar";

import ResultCard from "./components/cards/ResultCard";
import DomainCard from "./components/cards/DomainCard";
import SSLCard from "./components/cards/SSLCard";
import WhoisCard from "./components/cards/WhoisCard";
import SafeBrowsingCard from "./components/cards/SafeBrowsingCard";
import AIAnalysisCard from "./components/cards/AIAnalysisCard";

import RiskGauge from "./components/ui/RiskGauge";
import DownloadReportButton from "./components/ui/DownloadReportButton";

import {
  scanLocal,
  scanVirusTotal,
  scanSafeBrowsing,
} from "./services/api";